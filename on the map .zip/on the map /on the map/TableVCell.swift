//
//  TableVCell.swift
//  on the map
//
//  Created by Rawaa Alshafeai  on 07/05/1440 AH.
//  Copyright © 1440 udacity. All rights reserved.
//

import Foundation
import UIKit


class TableVCell :  UITableViewCell {
    
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var mediaURL: UILabel!
    
    var locationData: StudentLocation? {
        didSet {
            updateUI()
        }
    }
    
    func updateUI() {
        fullNameLabel.text = "\(locationData?.firstName ?? " ") \(locationData?.lastName ?? " ")"
        mediaURL.text = "\(locationData?.mediaURL ?? " ")"
    }
}
