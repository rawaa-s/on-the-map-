//
//  String+Date.swift
//  on the map
//
//  Created by Rawaa Alshafeai  on 06/05/1440 AH.
//  Copyright © 1440 udacity. All rights reserved.
//

import Foundation


extension String {
    var toDate: Date? {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter.date(from: self)
    }
}
