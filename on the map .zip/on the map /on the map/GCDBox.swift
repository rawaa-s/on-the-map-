//
//  GCDBox.swift
//  on the map
//
//  Created by Rawaa Alshafeai  on 07/05/1440 AH.
//  Copyright © 1440 udacity. All rights reserved.
//

import Foundation
import UIKit

// Perform updates on Main queue
func performUIUpdatesOnMain(_ updates: @escaping () -> Void) {
    DispatchQueue.main.async {
        updates()
    }
}

